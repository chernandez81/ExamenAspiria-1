import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ProductModel } from '../models/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {
  private url='http://localhost:50998/product';

  constructor(private http: HttpClient) { }

  crearProducto( producto: ProductModel ){
    return this.http.post(`${ this.url }`,producto);
  }

  actualizarProducto( producto: ProductModel ){
    console.log(producto);
    return this.http.put(`${ this.url }/${producto.id}`,producto);
  }

  getProductos(){
    return this.http.get(`${ this.url }`);
  }

  getProductosPorId(id: number){
    return this.http.get(`${ this.url }/${id}`);
  }

  deleteProducto(id: number){
    return this.http.delete(`${ this.url }/${id}`);
  }
}
