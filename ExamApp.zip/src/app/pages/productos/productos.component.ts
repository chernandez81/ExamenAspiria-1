import { Component, OnInit } from '@angular/core';
import { ProductosService } from '../../services/productos.service';
import { ProductModel } from '../../models/product.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-productos',
  templateUrl: './productos.component.html',
  styleUrls: ['./productos.component.css']
})
export class ProductosComponent implements OnInit {

  prod: any;
  cargando = false;
  constructor(private productosService: ProductosService) { }

  ngOnInit() {
    this.cargando = true;

    this.getProduct();
  }

  borrarroducto(product: ProductModel){
    Swal.fire({
      title: '¿Esta seguro?',
      text: `¿Esta sefuro que desea borrar a ${ product.name }?`,
      icon: 'question',
      showConfirmButton: true,
      showCancelButton: true
    }).then(resp => {
      if(resp.value){
        this.productosService.deleteProducto(product.id).subscribe();
        this.getProduct();
      }
    });
  }

  getProduct(){

    this.productosService.getProductos()
    .subscribe(resp => {
      this.prod = resp;
      this.cargando = false;
    });
    }
}
