import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ProductModel } from '../../models/product.model';
import { ProductosService } from '../../services/productos.service';
import Swal from 'sweetalert2';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-producto',
  templateUrl: './producto.component.html',
  styleUrls: ['./producto.component.css']
})
export class ProductoComponent implements OnInit {

  producto = new ProductModel();
  prod: any;
  constructor(private productosService: ProductosService,
              private route: ActivatedRoute) { }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');

    if(id !== 'nuevo'){
      this.productosService.getProductosPorId(Number(id))
      .subscribe( resp  => {
        this.prod = resp;
        this.producto.id = this.prod.id;
        this.producto.name = this.prod.name;
        this.producto.ageRestricted = this.prod.ageRestricted;
        this.producto.ageRestricted = this.prod.ageRestricted;
        this.producto.company = this.prod.company;
        this.producto.description = this.prod.description;
      });
    }
    console.log(id);
  }

  guardar( form: NgForm ){
    if(form.invalid) {
      console.log('Formulario invalido');
      return; }

    Swal.fire({
      title: 'Espere',
      text: 'Guardando informacion',
      icon: 'info',
      allowOutsideClick: false
    });

    Swal.showLoading();

    let peticion: Observable<any>;

    if(this.producto.id<=0)
    {
      peticion = this.productosService.crearProducto(this.producto);
    }else{
      peticion = this.productosService.actualizarProducto(this.producto);
    }

    peticion.subscribe (resp => {
      Swal.fire({
        title: this.producto.name,
        text: 'Se actualizo correctamente',
        icon: 'success',
      });
    });


  }
}
