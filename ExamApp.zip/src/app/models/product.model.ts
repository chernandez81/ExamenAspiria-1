export class ProductModel {
  id: number;
  name: string;
  description: string;
  ageRestricted: number;
  company: string;
  price: number;


  constructor(){
    this.id = 0;
    this.name = "";
    this.description = "";
    this.ageRestricted = 0;
    this.company = "";
    this.price = 0;
  }
}
