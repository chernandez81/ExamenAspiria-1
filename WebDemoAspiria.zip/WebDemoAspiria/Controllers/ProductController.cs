﻿using Domine;
using Microsoft.AspNetCore.Mvc;
using Persistency.Repository.Interface;
using System.Threading.Tasks;

namespace WebDemoAspiria.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductController  : ControllerBase
    {
        private readonly IProductRepository _productRepository;
        public ProductController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }
       
        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            var product = await  _productRepository.GetAllProducts();
            return Ok(product);
        }

        [HttpGet("{id}", Name ="GetProduct")]
        public async Task<IActionResult> GetProduct(int id)
        {
            var product = await _productRepository.GetProduct(id);
            if (product == null) return NotFound();
            return Ok(product);
        }

        [HttpPost]
        public async Task<IActionResult> CreateProduct([FromBody] Product product)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            if (await _productRepository.ProductExists(product.Name)) {
                ModelState.AddModelError(string.Empty, $"Ya existe un producto con el nombre de {product.Name}");
                return StatusCode(404,ModelState);
            }

            if (!await _productRepository.CreateProduct(product)) {
                ModelState.AddModelError(string.Empty,$"Ocurrio un error al guardar el producto {product.Name}");
                return StatusCode(500, ModelState);
            }

            return Ok(product);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] Product product)
        {
            if (!id.Equals(product.Id)) return BadRequest(ModelState);

            if (!await _productRepository.UpdateProduct(product))
            {
                ModelState.AddModelError(string.Empty, $"Ocurrio un error al actualizar el producto {product.Name}");
                return StatusCode(500, ModelState);
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id) {
            if (! await _productRepository.ProductExists(id)) return NotFound();

            var product = await _productRepository.GetProduct(id);

            if (! await _productRepository.DeleteProduct(product)) {
                ModelState.AddModelError(string.Empty, $"Ha ocurrido un error al eliminar el producto {product.Name}");
                return StatusCode(500, ModelState);
            }

            return NoContent();

        }
    }
}
