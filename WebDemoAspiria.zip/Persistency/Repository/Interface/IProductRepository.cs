﻿using Domine;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Persistency.Repository.Interface
{
    public interface IProductRepository
    {
        Task<IEnumerable<Product>> GetAllProducts();
        Task<Product> GetProduct(int id);
        Task<bool> ProductExists(string name);
        Task<bool> ProductExists(int id);
        Task<bool> CreateProduct(Product product);
        Task<bool> UpdateProduct(Product product);
        Task<bool> DeleteProduct(Product product);
        Task<bool> Save();
    }
}
