﻿using Domine;
using Microsoft.EntityFrameworkCore;
using Persistency.Context;
using Persistency.Repository.Interface;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Persistency.Repository.Implementation
{
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDbContext _context;
        public ProductRepository(ApplicationDbContext Context)
        {
            _context = Context;
        }
        public async Task<bool> CreateProduct(Product product)
        {
            _context.Product.Add(product);
            return await Save();
        }

        public async Task<bool> DeleteProduct(Product product)
        {
            _context.Product.Remove(product);
            return await Save();
        }

        public async Task<IEnumerable<Product>> GetAllProducts()
        {
            return await _context.Product.ToListAsync();
        }

        public async Task<bool> ProductExists(string name)
        {
            return await _context.Product.AnyAsync(x => x.Name.ToLower().Trim().Equals(name.ToLower().Trim()));
        }

        public async Task<bool> ProductExists(int id)
        {
            return await _context.Product.AnyAsync(x => x.Id.Equals(id));
        }

        public async Task<Product> GetProduct(int id)
        {
            return await _context.Product.FirstOrDefaultAsync(x => x.Id.Equals(id));
        }

        public async Task<bool> Save()
        {
            return await _context.SaveChangesAsync() > 0 ? true : false;
        }

        public async Task<bool> UpdateProduct(Product product)
        {
            _context.Product.Update(product);
            return await Save();
        }
    }
}
